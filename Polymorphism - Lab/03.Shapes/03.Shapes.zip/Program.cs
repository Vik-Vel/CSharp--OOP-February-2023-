﻿



namespace Shapes
{
    public class StartUp
    {
        public static void Main()
        {
            //Rectangle rectangle = new(2,2);
            //Circle circle = new Circle(3);

            //Console.WriteLine(rectangle.CalculateArea());
            //Console.WriteLine(rectangle.CalculatePerimeter());
            //Console.WriteLine(circle.CalculatePerimeter());
            //Console.WriteLine(circle.CalculateArea());



        }
    }
}
