﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.ShoppingSpree
{
    public static class ExceptionMessages
    {
        public const string NameExeptionMessage = "Name cannot be empty";
        public const string MoneyExeptionMessage = "Money cannot be negative";


    }
}
