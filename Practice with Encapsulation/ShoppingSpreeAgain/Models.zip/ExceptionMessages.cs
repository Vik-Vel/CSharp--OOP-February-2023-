﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingSpreeAgain
{
    public static class ExceptionMessages
    {
        public const  string NameExceptionMessage = "Name cannot be empty";
        public const  string MoneyExceptionMessage = "Money cannot be negative";
    }
}
